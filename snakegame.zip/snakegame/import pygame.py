import pygame
import random
import os

# Initialize Pygame
pygame.init()

# Define colors
white = (255, 255, 255)
black = (0, 0, 0)
red = (213, 50, 80)
bright_green = (0, 255, 0)
dark_green = (0, 200, 0)

# Display dimensions
dis_width = 800
dis_height = 600

# Create the display
dis = pygame.display.set_mode((dis_width, dis_height))
pygame.display.set_caption('Snake Game')

# Frame per second controller
clock = pygame.time.Clock()
snake_block = 20
snake_speed = 15

# Font style
font_style = pygame.font.SysFont('bahnschrift', 25)
score_font = pygame.font.SysFont('comicsansms', 35)

record_file = 'Desktop\snakegame\lecord1.txt'
leaderboard_file = 'Desktop\snakegame\leaderboard1.txt'

def load_record():
    if os.path.exists(record_file):
        with open(record_file, 'r') as file:
            content = file.read()
            if content.strip():  # Check if content is not empty
                return int(content)
            else:
                return 0  # Return a default value if the file is empty
    else:
        # Create the file and set the default record
        with open(record_file, 'w') as file:
            file.write('0')
        return 0  # Return a default value if the file does not exist

def save_record(record):
    with open(record_file, 'w') as file:
        file.write(str(record))

def load_leaderboard():
    if os.path.exists(leaderboard_file):
        with open(leaderboard_file, 'r') as file:
            leaderboard = [line.strip().split(',') for line in file.readlines()]
            return [(entry[0], int(entry[1])) for entry in leaderboard]
    else:
        return []

def save_leaderboard(leaderboard):
    with open(leaderboard_file, 'w') as file:
        for entry in leaderboard:
            file.write(f"{entry[0]},{entry[1]}\n")

def update_leaderboard(username, score):
    leaderboard = load_leaderboard()
    leaderboard.append((username, score))
    leaderboard = sorted(leaderboard, key=lambda x: x[1], reverse=True)[:5]
    save_leaderboard(leaderboard)

def draw_checker_pattern():
    block_size = 20
    for y in range(0, dis_height, block_size):
        for x in range(0, dis_width, block_size):
            if (x // block_size + y // block_size) % 2 == 0:
                color = bright_green
            else:
                color = dark_green
            pygame.draw.rect(dis, color, [x, y, block_size, block_size])

def our_snake(snake_block, snake_List):
    for x in snake_List:
        pygame.draw.rect(dis, black, [x[0], x[1], snake_block, snake_block])

def message(msg, color, y_displace=0):
    mesg = font_style.render(msg, True, color)
    dis.blit(mesg, [dis_width / 6, dis_height / 3 + y_displace])

def your_score(score):
    value = score_font.render(f"Your Score: {score}", True, white)
    dis.blit(value, [0, 0])

def show_leaderboard():
    leaderboard = load_leaderboard()
    dis.fill(black)
    message("Leaderboard", white, -200)
    for i, (username, score) in enumerate(leaderboard):
        message(f"{i + 1}. {username} - {score}", white, -100 + i * 30)
    message("Press any key to play again or Q to quit", red, 100)
    pygame.display.update()
    wait_for_key()

def wait_for_key():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_q:
                    pygame.quit()
                    quit()
                else:
                    return

def get_username():
    username = ""
    while True:
        dis.fill(black)
        message("Enter your username: " + username, white)
        pygame.display.update()
        for event in pygame.event.get():
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:
                    return username
                elif event.key == pygame.K_BACKSPACE:
                    username = username[:-1]
                else:
                    username += event.unicode
            elif event.type == pygame.QUIT:
                pygame.quit()
                quit()

def gameLoop():
    global record_score

    username = get_username()
    record_score = load_record()

    game_over = False
    game_close = False

    x1 = dis_width / 2
    y1 = dis_height / 2

    x1_change = 0
    y1_change = 0

    snake_List = []
    Length_of_snake = 1

    foodx = round(random.randrange(0, dis_width - snake_block) / 20.0) * 20.0
    foody = round(random.randrange(0, dis_height - snake_block) / 20.0) * 20.0

    # Track the current direction
    direction = None

    while not game_over:

        while game_close == True:
            draw_checker_pattern()
            message("You Lost! Press Q-Quit or C-Play Again", red)
            pygame.display.update()

            for event in pygame.event.get():
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_q:
                        game_over = True
                        game_close = False
                    if event.key == pygame.K_c:
                        # Update record and leaderboard if the current score is higher
                        if Length_of_snake - 1 > record_score:
                            record_score = Length_of_snake - 1
                            save_record(record_score)
                        update_leaderboard(username, Length_of_snake - 1)
                        gameLoop()  # Restart the game loop immediately

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_LEFT and direction != 'RIGHT':
                    x1_change = -snake_block
                    y1_change = 0
                    direction = 'LEFT'
                elif event.key == pygame.K_RIGHT and direction != 'LEFT':
                    x1_change = snake_block
                    y1_change = 0
                    direction = 'RIGHT'
                elif event.key == pygame.K_UP and direction != 'DOWN':
                    y1_change = -snake_block
                    x1_change = 0
                    direction = 'UP'
                elif event.key == pygame.K_DOWN and direction != 'UP':
                    y1_change = snake_block
                    x1_change = 0
                    direction = 'DOWN'

        if x1 >= dis_width or x1 < 0 or y1 >= dis_height or y1 < 0:
            game_close = True
        x1 += x1_change
        y1 += y1_change
        draw_checker_pattern()
        pygame.draw.rect(dis, red, [foodx, foody, snake_block, snake_block])
        snake_Head = []
        snake_Head.append(x1)
        snake_Head.append(y1)
        snake_List.append(snake_Head)
        if len(snake_List) > Length_of_snake:
            del snake_List[0]

        for x in snake_List[:-1]:
            if x == snake_Head:
                game_close = True

        our_snake(snake_block, snake_List)
        your_score(Length_of_snake - 1)  # Updated to only display the current score
        pygame.display.update()

        if x1 == foodx and y1 == foody:
            foodx = round(random.randrange(0, dis_width - snake_block) / 20.0) * 20.0
            foody = round(random.randrange(0, dis_height - snake_block) / 20.0) * 20.0
            Length_of_snake += 1

        clock.tick(snake_speed)

    # Update record and leaderboard if the current score is higher
    if Length_of_snake - 1 > record_score:
        record_score = Length_of_snake - 1
        save_record(record_score)
    update_leaderboard(username, Length_of_snake - 1)
    show_leaderboard()

    pygame.quit()
    quit()

gameLoop()
